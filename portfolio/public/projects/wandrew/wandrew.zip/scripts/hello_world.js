var colors = require('colors');

var init = function(){
	console.log("Hello World :)".cyan);
}

init();