'use strict';

/* Controllers */
var Controllers = angular.module('wandrew.controllers', []);

Controllers.controller('wandrewCtrl', ['$scope','Analytics','$http',
	function($scope,Analytics,$http) {
	

}]);
