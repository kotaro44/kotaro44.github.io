'use strict';

// Declare app level module which depends on filters, and services
angular.module('dmtree', [
  'dmtree.filters',
  'dmtree.services',
  'dmtree.directives',
  'dmtree.controllers'
]);
