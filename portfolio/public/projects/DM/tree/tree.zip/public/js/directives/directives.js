'use strict';

/* Directives */
var Directives = angular.module('dmtree.directives', []);

Directives.directive("dmTree", [function (LoadedFile) {
    return {
        restrict: 'E',
        templateUrl: 'public/partials/home.html',
        link: function (scope, element, attributes) {
    
        },
        controller: ['$scope','$http','$window','LoadedFile','$element',function($scope,$http,$window,LoadedFile,$element){
            $scope.data = {
                file: null,
                FPTree: null,
                tree: {
                    margin: {
                        top: 20, 
                        right: 120, 
                        bottom: 20, 
                        left: 120
                    },
                    width: 0,
                    height: 0,
                    i: 0,
                    duration: 750,
                    root: null,
                }
            };
       
            $scope.drawTree = function(){
                var treeProps = $scope.data.tree;
                treeProps.width = 4000 - treeProps.margin.right - treeProps.margin.left,
                treeProps.height = 800 - treeProps.margin.top - treeProps.margin.bottom;

                treeProps.tree = d3.layout.tree().size([treeProps.height, treeProps.width]);

                treeProps.diagonal = d3.svg.diagonal().projection(function(d){ 
                    return [d.y, d.x]; 
                });

                treeProps.svg = d3.select(".tree-holder").append("svg")
                    .attr("width", treeProps.width + treeProps.margin.right + treeProps.margin.left)
                    .attr("height", treeProps.height + treeProps.margin.top + treeProps.margin.bottom)
                    .append("g")
                    .attr("transform", "translate(" + treeProps.margin.left + "," + treeProps.margin.top + ")");

                d3.select(self.frameElement).style("height", "800px");

                setTimeout(function(){
                    treeProps.root = $scope.data.FPTree;
                    treeProps.root.x0 = treeProps.height/2;
                    treeProps.root.y0 = 0;

                    function collapse(d) {
                        if (d.children) {
                            d._children = d.children;
                            d._children.forEach(collapse);
                            d.children = null;
                        }
                    }

                    treeProps.root.children.forEach(collapse);
                    $scope.update(treeProps.root);
                },0);

                $scope.data.searchInput = $element.find('#search');
                $scope.data.searchInput.bind('keyup',function(){
                    $scope.data.searchText = $scope.data.searchInput.val();
                    $scope.data.FPTree.rules = [$scope.data.searchText];
                    $scope.$digest();
                });
            };

            $scope.update = function(source) {
                var treeProps = $scope.data.tree;

                // Compute the new tree layout.
                var nodes = treeProps.tree.nodes(treeProps.root).reverse(),
                    links = treeProps.tree.links(nodes);

                // Normalize for fixed-depth.
                nodes.forEach(function(d) { 
                    d.y = d.depth * 180; 
                });

                // Update the nodes…
                var node = treeProps.svg.selectAll("g.node").data(nodes, function(d) { 
                    return d.id || (d.id = ++treeProps.i); 
                });

                // Enter any new nodes at the parent's previous position.
                var nodeEnter = node.enter().append("g").attr("class", "node").attr("transform", function(d) { 
                    return "translate(" + source.y0 + "," + source.x0 + ")"; 
                }).on("click", $scope.click);

                nodeEnter.append("circle").attr("r", 1e-6).style("fill", function(d) { 
                    return d._children ? "lightsteelblue" : "#fff"; 
                });

                nodeEnter.append("text").attr("x", function(d) { 
                    return d.children || d._children ? -10 : 10; 
                }).attr("dy", "-0.75em").attr("text-anchor", function(d) { 
                    return d.children || d._children ? "end" : "start"; 
                }).text(function(d) { 
                    if( d.name == 'root' )
                        return d.name;
                    return d.name + ':' + d.count; 
                }).style("fill-opacity", 1e-6);

                // Transition nodes to their new position.
                var nodeUpdate = node.transition().duration(treeProps.duration).attr("transform", function(d) { 
                    return "translate(" + d.y + "," + d.x + ")"; 
                });

                nodeUpdate.select("circle").attr("r", 8 ).style("fill", function(d) { 
                    return d._children ? "lightsteelblue" : "#fff"; 
                });

                nodeUpdate.select("text").style("fill-opacity", 1);

                // Transition exiting nodes to the parent's new position.
                var nodeExit = node.exit().transition().duration(treeProps.duration).attr("transform", function(d) { 
                    return "translate(" + source.y + "," + source.x + ")"; 
                }).remove();

                nodeExit.select("circle").attr("r", 1e-6);
                nodeExit.select("text").style("fill-opacity", 1e-6);

                // Update the links…
                var link = treeProps.svg.selectAll("path.link").data(links, function(d) { 
                    return d.target.id; 
                });

                // Enter any new links at the parent's previous position.
                link.enter().insert("path", "g").attr("class", "link").attr("d", function(d) {
                    var o = {
                        x: source.x0, 
                        y: source.y0
                    };
                    return treeProps.diagonal({
                        source: o, 
                        target: o
                    });
                });

                // Transition links to their new position.
                link.transition().duration(treeProps.duration).attr("d", treeProps.diagonal);

                // Transition exiting nodes to the parent's new position.
                link.exit().transition().duration(treeProps.duration).attr("d", function(d) {
                    var o = {x: source.x, y: source.y};
                    return treeProps.diagonal({source: o, target: o});
                })
                .remove();

                // Stash the old positions for transition.
                nodes.forEach(function(d) {
                    d.x0 = d.x;
                    d.y0 = d.y;
                });
            };

            // Toggle children on click.
            $scope.click = function(d) {
                if (d.children) {
                    d._children = d.children;
                    d.children = null;
                } else {
                    d.children = d._children;
                    d._children = null;
                }
                $scope.update(d);
            }

            LoadedFile.loaded = function( newVal , oldVal ){
                if( newVal ){
                    $scope.data.FPTree = JSON.parse(newVal);
                    $scope.data.FPTree.rules = $scope.data.FPTree.rules.sort(function(a,b){
                        if( b.length > a.length )
                            return 1;
                        if( b.length < a.length )
                            return -1;
                        return b[b.length-1] - a[a.length-1];
                    }).map(function(a){
                        var support = a.pop();
                        return {
                            elements: a,
                            support: support
                        };
                    });

                    if( $scope.data.FPTree.fullRules ){
                        $scope.data.FPTree.fullRules = $scope.data.FPTree.fullRules.sort(function(a,b){
                            if( b.when.length > a.when.length )
                                return 1;
                            if( b.when.length < a.when.length )
                                return -1;

                            return b.confidence - a.confidence;
                        });
                    }

                    setTimeout(function(){
                        $scope.drawTree();
                    },100);
                }
            };

            LoadedFile.reload = function(){
                window.location.reload();
            };
        }]
    }
}]);

Directives.directive("rules", [function () {
    return {
        restrict: 'E',
        templateUrl: 'public/partials/rules.html',
        scope: {
            rules: '=',
            full: '=',
            total: '=',
            support: '='
        },
        link: function (scope, element, attributes) {
        
        },
        controller: ['$scope','LoadedFile',function($scope,LoadedFile){
            $scope.searchNumber = 1;
            $scope.confidence = 0;
            $scope.searchNumberMax = 10;
            $scope.maxShow = 100;
            $scope.data = {
                filtered: []
            };
            LoadedFile.changeText = function( input ){
                $scope.searchText = input.value;
                $scope.$digest();
            };
            LoadedFile.changeSupport = function( input ){
                $scope.support = input.value;
                $scope.$digest();
            };
            LoadedFile.changeNumber = function( input ){
                $scope.searchNumber = input.value;
                $scope.$digest();
            };
            LoadedFile.changeConfidence = function( input ){
                $scope.confidence = input.value;
                $scope.$digest();
            };
            LoadedFile.changeNumberMax = function( input ){
                $scope.searchNumberMax = input.value;
                $scope.$digest();
            };
            LoadedFile.changeNumberShow = function( input ){
                $scope.maxShow = input.value;
                $scope.$digest();
            };
            LoadedFile.saveRules = function(){
                var textToWrite = $scope.data.filtered.map(function(a){
                    var result = "";
                    for( var i = 0 ; i < a.when.length ; i++ )
                        result += a.when[i] + ',';
                    result += '->,' + a.then + ',' + (100*(a.support/$scope.total)).toFixed(2) + '%,' + a.confidencePer + '%,' + a.total + '\r\n';  
                    return result;
                });

                var textFileAsBlob = new Blob(textToWrite, {type:'csv'});
                var fileNameToSaveAs = "rules.csv";

                var downloadLink = document.createElement("a");
                downloadLink.download = fileNameToSaveAs;
                downloadLink.innerHTML = "Download File";
                if (window.webkitURL != null)
                {
                    downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
                }
                else
                {
                    downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
                    downloadLink.onclick = destroyClickedElement;
                    downloadLink.style.display = "none";
                    document.body.appendChild(downloadLink);
                }

                downloadLink.click();
            }
        }]
    }
}]);

Directives.directive("fileread", [function () {
    return {
        scope: {
            fileread: "="
        },
        link: function (scope, element, attributes) {
            element.bind("change", function (changeEvent) {
                var reader = new FileReader();
                reader.onload = function (loadEvent) {
                    scope.$apply(function () {
                        scope.fileread = loadEvent.target.result;
                        scope.LoadedFile.loaded( scope.fileread );
                    });
                }
                reader.readAsText(changeEvent.target.files[0]);
            });
        },
        controller: ['$scope','LoadedFile',function($scope,LoadedFile){
            $scope.LoadedFile = LoadedFile;
        }]
    }
}]);

Directives.directive("reddit", [function () {
    return {
        scope: {
            text: "="
        },
        restrict: 'E',
        template: '<a href="https://www.reddit.com/r/{{text}}">{{text}}</a>   '
    }
}]);

