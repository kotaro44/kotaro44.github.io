'use strict';

/* Controllers */
var Controllers = angular.module('dmtree.controllers', []);

Controllers.controller('treeCtrl', ['$scope','$http',
	function($scope,$http) {
		
}]);
